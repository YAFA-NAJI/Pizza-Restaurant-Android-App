package com.example.project;

public class Admininfo {
    // متغيرات ثابتة تمثل معلومات الإدمن الافتراضية

        public static final String DEFAULT_ADMIN_EMAIL = "jaser@yahoo.com";
    }




