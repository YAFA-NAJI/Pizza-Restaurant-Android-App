package com.example.project;

public final class userinfo {


    // Define constants for table name and column names
    public static class UserEntry {
        public static final String TABLE_NAME = "users";
        public static final String COLUMN_EMAIL = "email";
        public static final String COLUMN_PHONE = "phone";
        public static final String COLUMN_FIRST_NAME = "first_name";
        public static final String COLUMN_LAST_NAME = "last_name";
        public static final String COLUMN_GENDER = "gender";
        public static final String COLUMN_PASSWORD = "password";
    }
}
